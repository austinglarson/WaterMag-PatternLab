---
title: Tile
---

The tile block pattern contains a progress indicator, numeric value, and label for that numeric value.

Usage: displaying various types of data to users.
