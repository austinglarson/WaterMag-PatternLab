---
title: Landing Image
---

The Landing Image is a large block that typically appears at the top of the page and contains a large full-bleed image and a title.
