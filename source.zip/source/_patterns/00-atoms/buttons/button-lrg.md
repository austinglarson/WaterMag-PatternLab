---
title: Button Large
---

A larger version of the default button.