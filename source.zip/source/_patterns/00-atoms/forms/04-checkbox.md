---
title: Checkbox
---

[Insert description here]
