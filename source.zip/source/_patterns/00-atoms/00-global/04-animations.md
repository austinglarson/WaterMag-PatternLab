---
title: Animations
---

This is a demo of the animations that are being used on the page.