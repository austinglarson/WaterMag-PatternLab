---
title: Neutral Colors
---

The neutral color palette contains grayscale values that are used throughout the interface. For great tips about color in design systems, check out [this post](https://medium.com/eightshapes-llc/color-in-design-systems-a1c80f65fa3) by Nathan Curtis.
