---
title: Brand Colors
---

This color palette contains HikeTracker-specific colors to be used throughout the interface.
