This directory is the default target for pattern and site generation, as dictated by `patternlab-config.json`.
