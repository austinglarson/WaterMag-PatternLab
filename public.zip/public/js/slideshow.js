var $ = function (id) { 
	return document.getElementById(id); 
}

window.onload = function () {
    var slidesNode = $("slides");    
    var captionNode = $("caption");
    var imageNode = $("slide");
        
    var slides = slidesNode.getElementsByTagName("img");
    
    // Start slide show
    var image, imageCounter = 0;
    
    // goes to the next slide
    $("next").onclick = function() {
        imageCounter = (imageCounter + 1) % slides.length;
        image = slides[imageCounter];
        imageNode.src = image.src;
        captionNode.firstChild.nodeValue = image.alt;
    }

    // goes to the previous slide
    $("previous").onclick = function() {
        // first subtracts 1 from the imageCounter
        imageCounter = (imageCounter - 1);
        // then tests if it subtracts 1 from the first slide to bring it to the last slide
        if (imageCounter == -1) {
            imageCounter = 2;
        } else {
            imageCounter = imageCounter % slides.length;
        }
        image = slides[imageCounter];
        imageNode.src = image.src;
        captionNode.firstChild.nodeValue = image.alt;
    }
}